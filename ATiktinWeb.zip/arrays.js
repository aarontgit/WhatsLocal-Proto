"use strict"; // define the arrays of products, services, or events added to the cart, 10/31/20, Aaron Tiktin
var item = new Array();
var price = new Array();
var qty = new Array();
item=["3 tacos from Pablo's Tacos!", "2 pies at Top Pizza!", "Any crepe at Crepe City!", "Burger and fries from Burger Palace!"];
price=[5.00,7.00,5.00,6.00];
qty=[1,1,1,1];
